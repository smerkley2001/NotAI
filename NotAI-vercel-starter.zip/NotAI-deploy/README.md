# Not AI, Just I — Vercel prototype

Static prototype for the customizable shirt concept.

## Deploy
Upload `index.html` to the root of the GitHub repository, then import the repository into Vercel. No build command or framework configuration is required for this static version.
